
# Call Of Duty Discord Bot 

This project was something I had a lot of fun making. This discord bot 
fetches information from call of duty API and will display certain information.
This bot is meant for someone who owns a discord server and would like to check their own stats
or maybe the stats of their friends. Other cool things that this bot does is clear a certain number of messages in chat.


# Photos of the features

## Lifetime Stats
<img width="402" alt="Screen Shot 2022-06-24 at 8 48 29 PM" src="https://user-images.githubusercontent.com/90470559/175753734-f9a10866-0e7a-4dc0-b120-6e54f59aa76c.png">

## Weekly Stats 
<img width="395" alt="Screen Shot 2022-06-24 at 8 52 23 PM" src="https://user-images.githubusercontent.com/90470559/175753843-0e7ec205-eb34-4329-a215-bff50cb86320.png">

# Technologies used
Node.js
Discord.js
